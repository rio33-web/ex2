const swiper = new Swiper(".swiper", {
  loop: true, // ループ有効
  slidesPerView: 'auto', // 一度に表示する枚数
  loopedSlides: 2,  
  speed: 7000, // ループの時間
  allowTouchMove: false, // スワイプ無効
	spaceBetween: 0,
  autoplay: {
    delay: 0, // 途切れなくループ
  },
});
