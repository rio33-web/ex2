jQuery(function ($) {

  // hamburger----------------------------------------------------
  $('.js-hamburger').on('click', function(){
    $('.header__logo').toggleClass('header__logo2');
    $('.hamburger').toggleClass('hamburger2');
    $('.span').toggleClass('span2');
    $('.header-nav').toggleClass('header-nav2');
    $('.header-nav__items').toggleClass('header-nav__items2');
    
    // ドロワーメニューが開いている時の処理
    if ($(this).hasClass('open')) {
      $('.js-drawer').fadeOut();
      $(this).removeClass('open');
      $('html').removeClass('fixed');
    // ドロワーメニューが閉じている時の処理
    } else {
      $('.js-drawer').fadeIn();
      $(this).addClass('open');
      $('html').addClass('fixed');
    }
  });
  // hamburgerここまで-------------------------------------------------

  // accordion------------------------------------------------------
    $(".js-accordion-title").on('click', function () {
      $(this).toggleClass("open", 300);
      $(this).next().slideToggle(300); 
      $(".js-accordion-title").not(this).removeClass("open");
      $(".js-accordion-title").not(this).next().slideUp(300);
    });
  // accordionここまで--------------------------------------------
  

});